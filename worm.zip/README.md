# python-worm

Mohamed Samatar
run worm.py
does not contain extra credit